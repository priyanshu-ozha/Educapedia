<?php
ob_start();
session_start();

include "header.php";
include "connection.php";

?>
 <!-- Start main-content -->
 <div class="main-content">

<!-- Section: inner-header -->
<section class="inner-header divider parallax layer-overlay overlay-dark-5" data-bg-img="images/bg/bg6.jpg">
  <div class="container pt-70 pb-20">
    <!-- Section Content -->
    <div class="section-content">
      <div class="row">
        <div class="col-md-12 text-center">
          <h2 class="title text-white">Login</h2>
          
        </div>
      </div>
    </div>
  </div>
</section>

<section>
  <div class="container">
    <div class="row">
      <div class="col-md-6 col-md-push-3">
        <div class="border-1px p-25">

          <form id="appointment_form" name="appointment_form" class="mt-30" method="post" action="" enctype="multipart/form-data">
            <div class="row">
              <div class="col-sm-12">
                <div class="form-group mb-10">
                  <input name="email" class="form-control required email" type="email" placeholder="Enter Email" aria-required="true">
                </div>
              </div>
             
              <div class="col-sm-12">
                <div class="form-group mb-10">
                  <input name="pass" class="form-control required " type="password" placeholder="Enter Password" aria-required="true">
                </div>
              </div>
              <div class="col-sm-12">
                <div class="form-group mb-10">
                  <select name="type" class="form-control">
                    <option>-- Choose User Type--</option>
                    <option value="Faculty">Faculty</option>
                    <option value="Student">Student</option>
                    <option value="admin">Admin</option>
                  </select>
                </div>
              </div>
            </div>
           
            <div class="form-group mb-0 mt-20">
              <input name="form_botcheck" class="form-control" type="hidden" value="">
              <input type="submit" class="btn btn-primary" value="Login">
            </div>
          </form>
          
        </div>
      </div>
    </div>
  </div>
</section>
</div>  

<?php

if($_POST)
{ 

  // $file=htmlspecialchars($_POST['fac_email']);
  extract($_POST);


 
  $checkemail=filter_var($email,FILTER_VALIDATE_EMAIL);
  
  if($checkemail)
  {
        if($type=="Faculty")
        {
            $query = mysqli_query($con,"SELECT * from faculty_personal where email='$email' and password='$pass'");

            if(mysqli_num_rows($query)==0)
            {
              echo "<script>alert('Invalid Login');</script>";
            }
            else
            {
              $_SESSION['mysession'] = $email;
              header("location:faculty/index.php");
            }
        }
        else if($type=="Student")
        {
            $query = mysqli_query($con,"SELECT * from students where email='$email' and password='$pass'");

            if(mysqli_num_rows($query)==0)
            {
              echo "<script>alert('Invalid Login');</script>";
            }
            else
            {
              $_SESSION['mysession'] = $email;
              header("location:dashboard.php");
            }
        }
        else if($type="admin"){
          $query = mysqli_query($con,"SELECT * from users where email='$email' and password='$pass'");

            if(mysqli_num_rows($query)==0)
            {
              echo "<script>alert('Invalid Login');</script>";
            }
            else
            {
              $_SESSION['mysession'] = $email;
              header("location:admin-dashboard/index.php");
            }
          
        }
      
 
  }
  else{
    echo "Validation Failed";
  }


}



?>














<?php

include "footer.php";

?>
