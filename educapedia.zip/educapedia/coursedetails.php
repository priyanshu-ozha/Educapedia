<?php

 include "header.php";
 include "connection.php";

 $id = $_GET['id'];

 $query = mysqli_query($con,"SELECT * FROM courses where id='$id'");
while($k = mysqli_fetch_array($query))
{
    $course_name = $k['course_name'];
    $category_name = $k['category_name'];
    $details = $k['details'];
    $image = $k['image'];
    $amount = $k['amount'];
    $duration = $k['duration'];
    $prerequisite = $k['prerequisite'];
    $demo = $k['demo'];
    $fac_email=$k['email'];
}
$query1= mysqli_query($con,"SELECT * FROM faculty_personal where email='$fac_email'");
while($b = mysqli_fetch_array($query1))
{
 $fac_name=$b['name'];

}
$query2= mysqli_query($con,"SELECT * FROM fac_exp where email='$fac_email'");
while($c = mysqli_fetch_array($query2))
{
 $fac_about=$c['about'];
 

}


?>



  
  <!-- Start main-content -->

    
      
    <!-- Section: Student Details -->
    <section class="">
      <div class="container">
        <div class="section-content">
          <div class="row">
            <div class="col-xs-12 col-sm-8 col-md-8 pull-right pl-60 pl-sm-15">
              <div>
                <h3><?php echo $course_name; ?></h3>
                <h5 class="text-theme-colored"><b>Category :</b> <?php echo $category_name; ?> | <b>Amount :</b> <?php echo $amount; ?> | <b>Duration :</b> <?php echo $duration; ?> Hours</h5>
               
              </div>
                <ul class="nav nav-tabs mt-30">
                  <li class="active"><a data-toggle="tab" href="#tab1" aria-expanded="false">Course Description</a></li>
                  <li class=""><a data-toggle="tab" href="#tab2" aria-expanded="true">Prerequisite</a></li>
                 
                </ul>
                <div class="tab-content">
                  <div id="tab1" class="tab-pane fade active in">
                    <dl class="dl-horizontal doctor-info">
                      <p><?php echo $details; ?></p>
                      
                    </dl>
                  </div>
                  <div id="tab2" class="tab-pane fade">
                   <p>
                       <?php echo $prerequisite; ?>
                    </p>
                  </div>
                 
                </div>
              <!-- Portfolio Gallery Grid -->
              <br>
              <div class="row">
               
               <div class="col-md-12 mb-30">
                 
               <a href="buy.php?id=<?php echo $id; ?>" class="btn btn-primary">Buy Now</a>
                
               </div>
             </div>

              <div class="gallery-isotope grid-4 gutter-small clearfix" data-lightbox="gallery">
        
              </div>
              <!-- End Portfolio Gallery Grid -->

              <h3 class="text-uppercase title line-bottom mt-30">Demo <span class="text-theme-color-2 font-weight-700">Video</span></h3>
              <div class="row">
               
                <div class="col-md-6 mb-30">
                  
                  <div class="fluid-video-wrapper">
                    <iframe width="560" height="315" src="https://www.youtube.com/embed/<?php echo $demo; ?>" allowfullscreen></iframe>
                  </div>
                </div>
              </div>

              <div class="row">
               
               <div class="col-md-12 mb-30">
                 
               <a href="buy.php?id=<?php echo $id; ?>" class="btn btn-primary">Buy Now</a>
                
               </div>
             </div>
              <h3 class="text-uppercase title line-bottom mt-30">Recommend <span class="text-theme-color-2 font-weight-700">Courses</span></h3>
              <?php
                  $query2 = mysqli_query($con,"SELECT * FROM courses where category_name='$category_name' LIMIT 2");
                  while($k = mysqli_fetch_array($query2))
                  {
              ?>
              <div class="row mb-15">
                <div class="col-sm-6 col-md-4">
                  <div class="thumb"> <img alt="featured project" src="images/project/lg1.jpg" class="img-fullwidth"></div>
                </div>
                <div class="col-sm-6 col-md-8">
                  <h4 class="line-bottom mt-0 mt-sm-20"><?php echo $k['course_name']; ?></h4>
                  <ul class="review_text list-inline">
                    <li><h4 class="mt-0"><span class="text-theme-color-2">Price :</span> INR <?php echo $k['amount']; ?></h4></li>
                    <li>
                      <div class="star-rating" title="Rated 4.50 out of 5"><span style="width: 90%;">4.50</span></div>
                    </li>
                  </ul>
                  <a class="btn btn-dark btn-theme-colored btn-sm text-uppercase mt-10" href="coursedetails.php?id=<?php echo $k['id']; ?>">view details</a>
                </div>
              </div>
              <?php
                  }
                  ?>
            
            
            </div>
            <div class="col-sx-12 col-sm-4 col-md-4 sidebar pull-left">
              <div class="doctor-thumb">
                <img src="faculty/<?php echo $image; ?>" alt="">
              </div>
              <h4 class="line-bottom">About Faculty:</h4>
              <div class="volunteer-address">
                <ul>
                  <li>
                    <div class="bg-light media border-bottom-theme-colored-2px p-15 mb-20">
                      <div class="media-left">
                        <i class="fa fa-book text-theme-colored font-24 mt-5"></i>
                      </div>
                      <div class="media-body">
                        <h5 class="mt-0 mb-0">Teacher:</h5>
                        <h6><?php echo $fac_name; ?></h6>
                        <p> <?php echo $fac_about; ?></p>
                      </div>
                    </div>
                  </li>
                </ul>
              </div>
              
          </div>
        </div>
      </div>
    </section>

  </div>
  <!-- end main-content -->
  
  <!-- Footer -->
 






<?php
include "footer.php";

?>