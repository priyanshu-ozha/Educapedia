<?php
ob_start();
session_start();
$email = $_SESSION['mysession'];

if(!$email)
{
    header("location:login.php");
}

 include "header.php";
 include "connection.php";



?>



  
  <!-- Start main-content -->

    
      
    <!-- Section: Student Details -->
    
                
               
              <!-- Portfolio Gallery Grid -->
            

              <div class="gallery-isotope grid-4 gutter-small clearfix" data-lightbox="gallery">
        
              </div>
              <!-- End Portfolio Gallery Grid -->

             

              <div class="row">
                <?php
                    $query = mysqli_query($con,"select * from students where email='$email'");
                    while($k = mysqli_fetch_array($query))
                    {
                        $id= $k['id'];
                        $name = $k['name'];
                        $mobile = $k['mobile'];
                        $email = $k['email'];
                        $country = $k['country'];
                        $photo = $k['photo'];
                        
                    }
                ?>
                
               <div class="col-md-12 mb-30">
                    <strong>My Profile</strong> 
                    <div class="col-md-3">
                        <br> <br>
                            <img src="<?php echo $photo; ?>" style="width:200px;border-radius:50%;" alt="">
                    </div>

                    <div class="col-md-9">
                      
                    <br><br>
                        <table class="table" width="50%">
                            <tr>
                                <td><b>Name</b></td>
                                <td><?php echo $name; ?></td>
                            </tr>
                            <tr>
                                <td><b>Mobile</b></td>
                                <td><?php echo $mobile; ?></td>
                            </tr>
                            <tr>
                                <td><b>Country</b></td>
                                <td><?php echo $country; ?></td>
                            </tr>
                        </table>
                        <a href="updateprofile.php" class="btn btn-primary">Update Profile</a>
                        
                        <a href="change_password.php" class="btn btn-danger">Change Password</a>
                    </div>
                <p>
                   
                    
                </p>
                    
                
               </div>
             </div>
             
            
            
            </div>
            <div class="col-sx-12 col-sm-4 col-md-4 sidebar pull-left">
              
              <h4 class="line-bottom">Dashboard | <b><?php echo $email; ?></b></h3></h4>
              <div class="volunteer-address">
                <ul>
                  <li>
                    <div class="bg-light media border-bottom-theme-colored-2px p-15 mb-20">
                      <div class="media-left">
                        <i class="fa fa-book text-theme-colored font-24 mt-5"></i>
                      </div>
                      <div class="media-body">
                       <a href="courses.php">My Courses</a>
                      
                      </div>
                    </div>

                    <div class="bg-light media border-bottom-theme-colored-2px p-15 mb-20">
                      <div class="media-left">
                        <i class="fa fa-user text-theme-colored font-24 mt-5"></i>
                      </div>
                      <div class="media-body">
                       
                       <a href="updateprofile.php">Edit Profile</a>
                      </div>
                    </div>

                    <div class="bg-light media border-bottom-theme-colored-2px p-15 mb-20">
                      <div class="media-left">
                        <i class="fa fa-sign-out font-24 mt-5"></i>
                      </div>
                      <div class="media-body">
                       
                       <a href="logout.php">Signout</a>
                      </div>
                    </div>
                  </li>
                </ul>
              </div>
          </div>
        </div>
      </div>
    </section>

  </div>
  <!-- end main-content -->

  
  
  <!-- Footer -->
 






<?php
include "footer.php";

?>