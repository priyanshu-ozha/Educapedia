<?php

 include "header.php";
 include "connection.php";
if(!$email)
{
    header("location:login.php");
}





?>



  
  <!-- Start main-content -->

    
      
    <!-- Section: Student Details -->
    <section class="">
      <div class="container">
        <div class="section-content">
          <div class="row">
            <div class="col-xs-12 col-sm-8 col-md-8 pull-right pl-60 pl-sm-15">
              
                
               
              <!-- Portfolio Gallery Grid -->
            

              <div class="gallery-isotope grid-4 gutter-small clearfix" data-lightbox="gallery">
        
              </div>
              <!-- End Portfolio Gallery Grid -->

             

              <div class="row">
                <?php
                    $query = mysqli_query($con,"SELECT * from orders where student_email='$email'");
                    
                ?>
               <div class="col-md-12 mb-30">
                    <strong>My Courses</strong> 
                    

                    <div class="col-md-12">
                      
                    <br><br>
                        <table class="table">
                            <tr>
                                <td><b>Course Name</b></td>
                                <td><b>Amount</b></td>
                                <td><b>Provided By</b></td>
                            </tr>
                            <?php
                            while($k = mysqli_fetch_array($query))
                            {
                                $cname = $k['course_name'];
                                $amount = $k['amount'];
                                $faculty_email = $k['faculty_email'];
                                
                            ?>
                            
                            <tr>
                               <td><?php echo $cname; ?></td>
                            
                                <td><?php echo $amount; ?></td>
                           
                                <td><?php echo $faculty_email; ?></td>
                            </tr>
                            <?php
                            }
                            ?>
                        </table>
                    </div>
                <p>
                   
                    
                </p>
                    
                
               </div>
             </div>
             
            
            
            </div>
            <div class="col-sx-12 col-sm-4 col-md-4 sidebar pull-left">
              
              <h4 class="line-bottom">Dashboard | <b><?php echo $email; ?></b></h3></h4>
              <div class="volunteer-address">
                <ul>
                  <li>
                    <div class="bg-light media border-bottom-theme-colored-2px p-15 mb-20">
                      <div class="media-left">
                        <i class="fa fa-book text-theme-colored font-24 mt-5"></i>
                      </div>
                      <div class="media-body">
                       <a href="my-courses.php">My Courses</a>
                      
                      </div>
                    </div>

                    <div class="bg-light media border-bottom-theme-colored-2px p-15 mb-20">
                      <div class="media-left">
                        <i class="fa fa-user text-theme-colored font-24 mt-5"></i>
                      </div>
                      <div class="media-body">
                       
                       <a href="#">Edit Profile</a>
                      </div>
                    </div>

                    <div class="bg-light media border-bottom-theme-colored-2px p-15 mb-20">
                      <div class="media-left">
                        <i class="fa fa-sign-out font-24 mt-5"></i>
                      </div>
                      <div class="media-body">
                       
                       <a href="logout.php">Signout</a>
                      </div>
                    </div>
                  </li>
                </ul>
              </div>
          </div>
        </div>
      </div>
    </section>

  </div>
  <!-- end main-content -->
  
  <!-- Footer -->
 






<?php
include "footer.php";

?>