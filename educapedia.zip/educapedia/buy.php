<?php




 include "header.php";
 include "connection.php";

 $id = $_GET['id'];

 

$query = mysqli_query($con,"SELECT * FROM courses where id='$id'");
while($k = mysqli_fetch_array($query))
{
    $course_name = $k['course_name'];
    $category_name = $k['category_name'];
    $details = $k['details'];
    $image = $k['image'];
    $amount = $k['amount'];
    $duration = $k['duration'];
    $prerequisite = $k['prerequisite'];
    $demo = $k['demo'];
    $faculty_email = $k['email'];
}
?>

 
 

  
  <!-- Start main-content -->

    
      
    <!-- Section: Student Details -->
    <section class="">
      <div class="container">
        <div class="section-content">
          <div class="row">
            <div class="col-xs-12 col-sm-8 col-md-8 pull-right pl-60 pl-sm-15">
              <div>
                <h3>Course : <?php echo $course_name; ?></h3>
                
              </div>
                
               
              <!-- Portfolio Gallery Grid -->
            

              <div class="gallery-isotope grid-4 gutter-small clearfix" data-lightbox="gallery">
        
              </div>
              <!-- End Portfolio Gallery Grid -->

             

              <div class="row">
               
               <div class="col-md-12 mb-30">
                 
               <form id="appointment_form" name="appointment_form" class="mt-30" method="POST" action="">
            <div class="row">
              <div class="col-sm-12">
                <div class="form-group mb-10">
                    
                  <input name="cname" value="<?php echo $course_name; ?>" class="form-control" type="text" required="" readonly>
                </div>
              </div>
              <div class="col-sm-12">
                <div class="form-group mb-10">
                  <input name="ccategory" class="form-control required" type="text" value="<?php echo $category_name; ?>" readonly>
                </div>
              </div>
              <div class="col-sm-12">
                <div class="form-group mb-10">
                <input name="semail" class="form-control required" type="hidden" value="<?php echo $email; ?>" readonly>
                </div>
              </div>
              
                <div class="col-sm-12">
                <div class="form-group mb-10">
                <input name="amount" class="form-control required" type="text" value="<?php echo $amount; ?>" readonly>
                </div>
              </div>

              <div class="col-sm-12">
                <div class="form-group mb-10">
                <input name="date" class="form-control required" type="date">
                </div>
              </div>

              <div class="col-sm-12">
                <div class="form-group mb-10">
                <input name="faculty_email" class="form-control required" type="hidden" value="<?php echo $faculty_email; ?>" readonly>
                </div>
              </div>

              <div class="col-sm-12">
                <div class="form-group mb-10">
                <select name="payment" id="" required class="form-control">
                  <option value="">---Choose---</option>
                  <option value="offline">Offline</option>
                  <option value="online">Online</option>
                </select>
                </div>
              </div>
             

            </div>
           
            <div class="form-group mb-0 mt-20">
              <input name="form_botcheck" class="form-control" type="hidden" value="">
              <button type="submit" class="btn btn-dark btn-theme-colored" data-loading-text="Please wait...">Buy</button>
            </div>
          </form>
           
            <?php

                if($_POST)
                {
                    extract($_POST);

                    if($email)
                    {

                    mysqli_query($con,"INSERT into orders values('','$cname','$ccategory','$semail','$amount','$faculty_email','$date')");

                    if($payment=="online")
                    {
                      $_SESSION['amount'] = $amount;
                      $_SESSION['name']=$cname;

                       
                      //redirect to payumoney
                      echo "<script>window.location.href='payment.php';</script>";

                      // ob_start();
                      // header('location:payment1.php');
                    }
                    else
                    {
                      // send email to user

                      echo "<script>alert('You have sucessfully purchased Course!')</script>";
                    }
                }
                }
            ?>
                
               </div>
             </div>
             
            
            
            </div>
            <div class="col-sx-12 col-sm-4 col-md-4 sidebar pull-left">
              <div class="doctor-thumb">
                <img src="faculty/<?php echo $image; ?>" alt="">
              </div>
              <h4 class="line-bottom"><?php echo $course_name; ?></h4>
              <div class="volunteer-address">
                <ul>
                  <li>
                    <div class="bg-light media border-bottom-theme-colored-2px p-15 mb-20">
                      <div class="media-left">
                        <i class="fa fa-book text-theme-colored font-24 mt-5"></i>
                      </div>
                      <div class="media-body">
                        <h5 class="mt-0 mb-0">Category:</h5>
                        <p><?php echo $category_name; ?></p>
                      </div>
                    </div>
                  </li>
                  <li>
                    <div class="bg-light media border-bottom-theme-colored-2px p-15 mb-20">
                      <div class="media-left">
                        <i class="fa fa-map-marker text-theme-colored font-24 mt-5"></i>
                      </div>
                      <div class="media-body">
                        <h5 class="mt-0 mb-0">Price:</h5>
                        <p><?php echo $amount; ?></p>
                      </div>
                    </div>
                    </li>
                    
                </ul>
              </div>
          </div>
        </div>
      </div>
    </section>

  </div>
  <!-- end main-content -->
  
  <!-- Footer -->
 






<?php
include "footer.php";

?>