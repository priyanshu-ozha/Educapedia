-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Apr 03, 2022 at 10:45 AM
-- Server version: 10.4.22-MariaDB
-- PHP Version: 8.1.2

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `edu`
--

-- --------------------------------------------------------

--
-- Table structure for table `categories`
--

CREATE TABLE `categories` (
  `id` int(11) NOT NULL,
  `category_name` varchar(40) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `categories`
--

INSERT INTO `categories` (`id`, `category_name`) VALUES
(1, 'WEB DEVELOPMENT');

-- --------------------------------------------------------

--
-- Table structure for table `courses`
--

CREATE TABLE `courses` (
  `id` int(11) NOT NULL,
  `category_name` varchar(40) NOT NULL,
  `course_name` varchar(40) NOT NULL,
  `faculty_email` varchar(30) NOT NULL,
  `details` longtext NOT NULL,
  `image` varchar(500) NOT NULL,
  `duration` varchar(40) NOT NULL,
  `amount` int(10) NOT NULL,
  `prerequisite` varchar(500) NOT NULL,
  `demo` longtext NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `courses`
--

INSERT INTO `courses` (`id`, `category_name`, `course_name`, `faculty_email`, `details`, `image`, `duration`, `amount`, `prerequisite`, `demo`) VALUES
(3, 'Php Development', 'Laravel', 'rahul@gmail.com', 'Learn the Latest Framework Laravel 8.', 'uploads/faculty/AcA2LnWL_400x400.jpg', '8', 3000, 'PHP MySQL', 'OSkj5P9TboM');

-- --------------------------------------------------------

--
-- Table structure for table `enquiries`
--

CREATE TABLE `enquiries` (
  `id` int(11) NOT NULL,
  `subject` varchar(40) NOT NULL,
  `student_email` varchar(40) NOT NULL,
  `message` varchar(255) NOT NULL,
  `date` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `faculty_personal`
--

CREATE TABLE `faculty_personal` (
  `id` int(11) NOT NULL,
  `name` varchar(40) NOT NULL,
  `email` varchar(40) NOT NULL,
  `mobile` int(10) NOT NULL,
  `password` varchar(40) NOT NULL,
  `photo` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `faculty_personal`
--

INSERT INTO `faculty_personal` (`id`, `name`, `email`, `mobile`, `password`, `photo`) VALUES
(1, 'amit', 'amit@gmail.com', 2147483647, 'abc', 'faculty/uploads/fac_personal/01.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `fac_exp`
--

CREATE TABLE `fac_exp` (
  `id` int(11) NOT NULL,
  `email` varchar(40) NOT NULL,
  `domain` varchar(40) NOT NULL,
  `experience` varchar(200) NOT NULL,
  `about` longtext NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `fac_exp`
--

INSERT INTO `fac_exp` (`id`, `email`, `domain`, `experience`, `about`) VALUES
(1, 'amit@gmail.com', 'WEB DEVELOPMENT', '1', 'Good Trainer of Web Development');

-- --------------------------------------------------------

--
-- Table structure for table `fac_stu`
--

CREATE TABLE `fac_stu` (
  `id` int(11) NOT NULL,
  `email` varchar(40) NOT NULL,
  `total_students` int(100) NOT NULL,
  `total_reviews` int(100) NOT NULL,
  `demo_youtube_link` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `orders`
--

CREATE TABLE `orders` (
  `id` int(11) NOT NULL,
  `cname` varchar(30) NOT NULL,
  `ccategory` varchar(30) NOT NULL,
  `semail` varchar(30) NOT NULL,
  `amount` int(30) NOT NULL,
  `faculty_email` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `orders`
--

INSERT INTO `orders` (`id`, `cname`, `ccategory`, `semail`, `amount`, `faculty_email`) VALUES
(1, 'Laravel', 'Php Development', 'gk@gmail.com', 3000, 'rahul@gmail.com'),
(2, 'Laravel', 'Php Development', 'gk@gmail.com', 3000, 'rahul@gmail.com'),
(3, 'Laravel', 'Php Development', 'gk@gmail.com', 3000, 'gk@gmail.com'),
(4, 'Laravel', 'Php Development', 'ojha@gmai.com', 3000, 'rahul@gmail.com'),
(5, 'Laravel', 'Php Development', 'ojha@gmai.com', 3000, 'rahul@gmail.com'),
(6, 'Laravel', 'Php Development', 'ojha@gmai.com', 3000, 'rahul@gmail.com'),
(7, 'Laravel', 'Php Development', 'ojha@gmai.com', 3000, 'rahul@gmail.com'),
(8, 'Laravel', 'Php Development', 'ojha@gmai.com', 3000, 'rahul@gmail.com'),
(9, 'Laravel', 'Php Development', 'ojha@gmai.com', 3000, 'rahul@gmail.com');

-- --------------------------------------------------------

--
-- Table structure for table `otp`
--

CREATE TABLE `otp` (
  `id` int(11) NOT NULL,
  `email` varchar(20) NOT NULL,
  `otp` varchar(4) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `otp`
--

INSERT INTO `otp` (`id`, `email`, `otp`) VALUES
(4, 'gk@gmail.com', '3083');

-- --------------------------------------------------------

--
-- Table structure for table `students`
--

CREATE TABLE `students` (
  `id` int(11) NOT NULL,
  `name` varchar(30) NOT NULL,
  `mobile` int(10) NOT NULL,
  `email` varchar(40) NOT NULL,
  `password` varchar(40) NOT NULL,
  `country` varchar(40) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `students`
--

INSERT INTO `students` (`id`, `name`, `mobile`, `email`, `password`, `country`) VALUES
(7, 'Govind', 2147483647, 'prnshozha@gmail.com', 'abcdef', 'India'),
(8, 'Govind', 2147483647, 'mauryarampratap398@gmail.com', 'abcdef', 'Afganistan'),
(9, 'Himanshu', 2147483647, 'ojha@gmai.com', 'abcd', 'Afganistan'),
(10, 'Govind', 2147483647, 'gk@gmail.com', '1234', 'India');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(100) NOT NULL,
  `user_type` varchar(2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `username`, `password`, `user_type`) VALUES
(1, 'admin', '21232f297a57a5a743894a0e4a801fc3', '1'),
(2, 'rahul', '439ed537979d8e831561964dbbbd7413', '2');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `categories`
--
ALTER TABLE `categories`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `courses`
--
ALTER TABLE `courses`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `enquiries`
--
ALTER TABLE `enquiries`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `faculty_personal`
--
ALTER TABLE `faculty_personal`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `fac_exp`
--
ALTER TABLE `fac_exp`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `fac_stu`
--
ALTER TABLE `fac_stu`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `orders`
--
ALTER TABLE `orders`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `otp`
--
ALTER TABLE `otp`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `students`
--
ALTER TABLE `students`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `categories`
--
ALTER TABLE `categories`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `courses`
--
ALTER TABLE `courses`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `enquiries`
--
ALTER TABLE `enquiries`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `faculty_personal`
--
ALTER TABLE `faculty_personal`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `fac_exp`
--
ALTER TABLE `fac_exp`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `fac_stu`
--
ALTER TABLE `fac_stu`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `orders`
--
ALTER TABLE `orders`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `otp`
--
ALTER TABLE `otp`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `students`
--
ALTER TABLE `students`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
