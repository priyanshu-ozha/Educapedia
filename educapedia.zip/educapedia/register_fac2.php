<?php

session_start();
$fac_email=$_SESSION['session'];
include "header.php";
include "connection.php";


?>
 <!-- Start main-content -->
 <div class="main-content">

<!-- Section: inner-header -->
<section class="inner-header divider parallax layer-overlay overlay-dark-5" data-bg-img="images/bg/bg6.jpg">
  <div class="container pt-70 pb-20">
    <!-- Section Content -->
    <div class="section-content">
      <div class="row">
        <div class="col-md-12 text-center">
          <h2 class="title text-white">Faculty Registration - Step 2 (Enter Your Experience)</h2>
          
        </div>
      </div>
    </div>
  </div>
</section>

<section>
  <div class="container">
    <div class="row">
      <div class="col-md-6 col-md-push-3">
        <div class="border-1px p-25">

          <form class="mt-30" method="post" action="" enctype="multipart/form-data">
            <div class="row">
              <div class="col-sm-12">
                <div class="form-group mb-10">
                  <b>Category :</b>
                  <select name="fac_domain" class="form-control">
                  <?php
                      $query = mysqli_query($con,"select * from categories");
                      while($k = mysqli_fetch_array($query))
                      {
                        ?>
                          <option value="<?php echo $k['category_name']; ?>">
                            <?php echo $k['category_name']; ?>
                        </option>
                        <?php
                      }
                  ?>
                  </select>
                </div>
              </div>
              <div class="col-sm-12">
                <div class="form-group mb-10">
                  <b>Experience (in Yrs) :</b>
                <select id="experience" name="fac_exp" class="form-control required ">
                <option value="1">1</option>
               <option value="1-3">1-3</option>
               <option value="3-5">3-5</option>
               <option value="5-10">5-10</option>
               <option value=">10">More Then 10</option>
               <option value="fresher">Fresher</option>
                </select>
                </div>
              </div>
              <div class="col-sm-12">
                <div class="form-group mb-10">
                  <b>Introduce Yourself :</b>
                  <br>
                  <textarea name="fac_about" class="form-control"></textarea>
                </div>
              </div>
              <br>
              
            </div>
           
            <div class="form-group mb-0 mt-20">
              <input name="form_botcheck" class="form-control" type="hidden" value="">
              <input type="submit" class="btn btn-primary" value="Register Now">
            </div>
          </form>
         
        </div>
      </div>
    </div>
  </div>
</section>
</div>  

<?php

if($_POST)
{
  $fac_domain=htmlspecialchars($_POST['fac_domain']);
  $fac_exp=htmlspecialchars($_POST['fac_exp']);
  $fac_about=htmlspecialchars($_POST['fac_about']);

  mysqli_query($con,"INSERT INTO fac_exp VALUES('','$fac_email','$fac_domain','$fac_exp','$fac_about');");
    ?>
    <script>
        alert("You are successfully registered");
    </script>
    <?php
    header("location:login.php");

}

?>














<?php

include "footer.php";

?>
