<?php

include "header.php";
include "connection.php";
if(!$email)
{
    header("location:login.php");
}




?>



  
  <!-- Start main-content -->

    
      
    <!-- Section: Student Details -->
    
                
               
              <!-- Portfolio Gallery Grid -->
            

              <div class="gallery-isotope grid-4 gutter-small clearfix" data-lightbox="gallery">
        
              </div>
              <!-- End Portfolio Gallery Grid -->

             

              <div class="row">
               
               
                
               <div class="col-md-12 mb-30">
                    
                  

                    <div class="col-md-12">

                    <?php
                    $query = mysqli_query($con,"SELECT * FROM orders WHERE email='$email'");
                ?>
                <table class="table table-bordered">
                <tr>
                    <th><b>Course</b></th>
                    <th><b>Category</b></th>
                    <th><b>Date</b></th>
                    <th><b>Amount</b></th>     
                             
                </tr> 
                      
                    <?php
                    while($k = mysqli_fetch_array($query))
                    {
                        ?>
                        <Tr>
                            <td><?php echo $k['course_name']; ?></td>
                            <td><?php echo $k['category_name']; ?></td>
                            <td><?php echo $k['date']; ?></td>
                            <td><?php echo $k['amount']; ?></td>
                        </Tr>
                        <?php

                    }
                ?>
                </table>
                    </div>
                <p>
                   
                    
                </p>
                    
                
               </div>
             </div>
             
            
            
            </div>
            <div class="col-sx-12 col-sm-4 col-md-4 sidebar pull-left">
              
              <h4 class="line-bottom">Dashboard | <b><?php echo $email; ?></b></h3></h4>
              <div class="volunteer-address">
                <ul>
                  <li>
                    <div class="bg-light media border-bottom-theme-colored-2px p-15 mb-20">
                      <div class="media-left">
                        <i class="fa fa-book text-theme-colored font-24 mt-5"></i>
                      </div>
                      <div class="media-body">
                       <a href="my-courses.php">My Courses</a>
                      
                      </div>
                    </div>

                    <div class="bg-light media border-bottom-theme-colored-2px p-15 mb-20">
                      <div class="media-left">
                        <i class="fa fa-user text-theme-colored font-24 mt-5"></i>
                      </div>
                      <div class="media-body">
                       
                       <a href="#">Edit Profile</a>
                      </div>
                    </div>

                    <div class="bg-light media border-bottom-theme-colored-2px p-15 mb-20">
                      <div class="media-left">
                        <i class="fa fa-sign-out font-24 mt-5"></i>
                      </div>
                      <div class="media-body">
                       
                       <a href="logout.php">Signout</a>
                      </div>
                    </div>
                  </li>
                </ul>
              </div>
          </div>
        </div>
      </div>
    </section>

  </div>
  <!-- end main-content -->

  
  
  <!-- Footer -->
 






<?php
include "footer.php";

?>