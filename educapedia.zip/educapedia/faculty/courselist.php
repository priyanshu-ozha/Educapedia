<?php
include "header.php";

?>




</div>    <div class="app-main__outer">
                    <div class="app-main__inner">
                        <div class="app-page-title">
                            <div class="page-title-wrapper">
                                <div class="page-title-heading">
                                    <div class="page-title-icon">
                                        <i class="pe-7s-car icon-gradient bg-mean-fruit">
                                        </i>
                                    </div>
                                    <div>Students
                                    </div>
                                </div>
                            </div>           
                       
                        <div class="row">
                            
                            <div class="d-xl-none d-lg-block col-md-6 col-xl-4">
                                <div class="card mb-3 widget-content">
                                    <div class="widget-content-outer">
                                        <div class="widget-content-wrapper">
                                            <div class="widget-content-left">
                                                <div class="widget-heading">Income</div>
                                                <div class="widget-subheading">Expected totals</div>
                                            </div>
                                            <div class="widget-content-right">
                                                <div class="widget-numbers text-focus">$147</div>
                                            </div>
                                        </div>
                                        <div class="widget-progress-wrapper">
                                            <div class="progress-bar-sm progress-bar-animated-alt progress">
                                                <div class="progress-bar bg-info" role="progressbar" aria-valuenow="54" aria-valuemin="0" aria-valuemax="100" style="width: 54%;"></div>
                                            </div>
                                            <div class="progress-sub-label">
                                                <div class="sub-label-left">Expenses</div>
                                                <div class="sub-label-right">100%</div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-12">
                                <div class="main-card mb-3 card">
                                    <div class="card-header">Course List
                                        
                                    </div>
                                <div class="table-responsive">
                                   <?php
                                     include "../myclass.php";
                                     $obj1=new myclass("localhost","root","",'edu');
                                     $k=$obj1->displaycourse($email);
                                   ?>
                                </div>
                                <TABLE border="2" class="table" id="displaycourse">
                                       <thead>
                                            <tr>
                                                <th>Category Name</th>
                                                <th>Course Name</th>
                                                <th>Details</th>
                                                <th>Image</th>
                                                <th>Duration</th>
                                                <th>Amount</th>
                                                <th>Prerequisites</th>
                                                <th>Demo</th>
                                                 
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php
                                            foreach($k as $z)
                                            {
                                            ?>
                                            <tr>
                                                <td><?php echo $z['category_name']; ?></td>
                                                <td><?php echo $z['course_name']; ?></td>
                                                <td><?php echo $z['details']; ?></td>
                                                <td><img src="../faculty/<?php echo $z['image']; ?>" alt="" height="100px" width="100px"></td>
                                                <td><?php echo $z['duration']; ?></td>
                                                <td><?php echo $z['amount']; ?></td>
                                                <td><?php echo $z['prerequisite']; ?></td>
                                                <td>
                                                <iframe width="100" height="100" src="https://www.youtube.com/embed/<?php echo $z['demo']; ?>" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen ></iframe>
                                                </td>
                                                <td>
                                                    <a href="delete.php?id=<?php echo $z['id']; ?>&type=course">Delete</a>
                                                </td>
                                            </tr>

                                            <?php
                                            }
                                            ?>
                                        </tbody>

                                        

                                    </table>
                                   
                                </div>
                            </div>
                        </div>






















<?php
include "footer.php";

?>