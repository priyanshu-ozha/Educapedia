<?php

include "header.php";
include "connection.php";
$id=$_GET['id'];
$p=mysqli_query($con,"SELECT * FROM categories");
while($z=mysqli_fetch_array($p)){
    $category_name=$z['category_name'];
    
}
?>








 <!-- Section: courses  -->
 <section id="courses">
      <div class="container pr-5 pl-5 mt-0 pt-70 pb-10 mb-0">
        <div class="section-title text-center">
          <div class="row">
            <div class="col-md-12">
              <h2 class="mt-0 line-height-1 text-center text-uppercase mb-10 text-black-333">Trending <span class="text-theme-color-2"> Courses</span></h2>
              
              </div>
              <!-- End Works Filter -->
              
              <!-- Portfolio Gallery Grid -->
              <div id="grid-petcare-gallery" class="gallery-isotope grid-4 gutter clearfix">
                
              <?php
                        $query = mysqli_query($con,"SELECT * FROM courses WHERE category_name='$category_name'");
                        while($k = mysqli_fetch_array($query))
                        {
                    ?>
                <!-- Portfolio Item Start -->
                <div class="gallery-item computer" style="margin-top:5%">
                  <div class="item">
                    <div class="project mb-30 border-2px">
                      <div class="thumb">
                        <img class="img-fullwidth" alt="" src="faculty/<?php echo $k['image']; ?>">
                        <div class="hover-link">
                        <a class="btn btn-flat btn-dark btn-theme-colored btn-md pull-left font-20" href="coursedetails.php?id=<?php echo $k['id']; ?>">
                        <span>INR <?php echo $k['amount']; ?></span> 
                       </a>
                        </div>
                      </div>
                  <div class="project-details p-15 pt-10 pb-10">
                    <h5 class="font-14 font-weight-500 mb-5"><?php echo $k['category_name']; ?></h5>
                    <h4 class="font-weight-700 text-uppercase mt-0">
                      <a href="coursedetails.php?id=<?php echo $k['id']; ?>">
                        <?php echo $k['course_name']; ?>
                      </a></h4>
                      </div>
                    </div>
                  </div>
                </div>
                <!-- Portfolio Item End -->
                <?php } ?>
               


              </div>
              <!-- End Portfolio Gallery Grid -->
            </div>
          </div>
        </div>
      </div>
    </section>




















<?php
include "footer.php";
?>