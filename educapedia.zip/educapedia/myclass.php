<?php
class myclass
{
  public $dbhost;
  public $dbuser;
  public $dbpass;
  public $dbname;
  public $con;

  function __construct($dbhost,$dbuser,$dbpass,$dbname)
  {
      $this->dbhost=$dbhost;
      $this->dbuser=$dbuser;
      $this->dbpass=$dbpass;
      $this->dbname=$dbname;

      $this->con= new PDO("mysql:host=$this->dbhost;dbname=$this->dbname", $this->dbuser, $this->dbpass);
      
  }


  function login($username,$password,$user_type)
  {
    $k=$this->con->prepare("SELECT * FROM users WHERE username='$username' AND password='$password' ");
    $k->execute();
    $count= $k->rowCount();
    if($count==1)
    {
        session_start();
        $_SESSION['mysession'] = $username;

        if($user_type==1)
        {
            header("location:admin-dashboard/index.php");
        }
        else if($user_type==2)
        {
            header("location:faculty/index.php");
        }
        
    }
    else
    {
        echo "Invalid Login";
    }
    }



    function uploadcategory($categoryname){
        $u=$this->con->prepare("INSERT INTO categories VALUES('','$categoryname')");
        $u->execute();
        echo "Category Uploaded Successfully";
    }

    
    function displaycategory()
    {
        $v=$this->con->prepare("SELECT * FROM categories");
        $v->execute();
        $row = $v->fetchAll(PDO::FETCH_ASSOC);
        return $row;

    }
    function displaystudent()
    {
        $v=$this->con->prepare("SELECT * FROM students");
        $v->execute();
        $row = $v->fetchAll(PDO::FETCH_ASSOC);
        return $row;

    }

    function displaycourselist()
    {
        $v=$this->con->prepare("SELECT * FROM courses");
        $v->execute();
        $row = $v->fetchAll(PDO::FETCH_ASSOC);
        return $row;
        

    }

    function displaycourse($email)
    {
        $v=$this->con->prepare("SELECT * FROM courses where email='$email'");
        $v->execute();
        $row = $v->fetchAll(PDO::FETCH_ASSOC);
        return $row;
        

    }



    function displayteacherlist()
    {
        $v=$this->con->prepare("SELECT * FROM faculty_personal");
        $v->execute();
        $row = $v->fetchAll(PDO::FETCH_ASSOC);
        return $row;
       

    }
  

 /*function register($name,$mobile,$email,$password,$country)
 {
     $k= $this->conn->prepare("INSERT INTO students VALUES('','$name','$mobile','$email','$password','$country')");
     $k->execute();
     echo "Registered Succesfully";
 }
 */
/*
function enquiry($subject,$student_email,$message,$date)
{
    $k= $this->conn->prepare("INSERT INTO enquiry VALUES('','$subject','$student_email','$message','$date')");
     $k->execute();
     echo "Registered Succesfully";

*/
    

    function uploadcourses($category,$course,$email,$duration,$amount,$prerequisite,$course_details,$merge,$demo)
    {
        $u=$this->con->prepare("INSERT INTO courses VALUES('','$category','$course','$email','$course_details','$merge','$duration','$amount','$prerequisite','$demo')");
        $u->execute();
        
    }
}

?>

<script>
    $(document).ready( function () {
        $('#uploadcategory').DataTable();
    } );
    </script>