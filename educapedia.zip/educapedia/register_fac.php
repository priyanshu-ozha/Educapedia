<?php
ob_start();
session_start();

include "header.php";
include "connection.php";

?>
 <!-- Start main-content -->
 <div class="main-content">

<!-- Section: inner-header -->
<section class="inner-header divider parallax layer-overlay overlay-dark-5" data-bg-img="images/bg/bg6.jpg">
  <div class="container pt-70 pb-20">
    <!-- Section Content -->
    <div class="section-content">
      <div class="row">
        <div class="col-md-12 text-center">
          <h2 class="title text-white">Faculty Registration Form - Step 1</h2>
          
        </div>
      </div>
    </div>
  </div>
</section>

<section>
  <div class="container">
    <div class="row">
      <div class="col-md-6 col-md-push-3">
        <div class="border-1px p-25">

          <form id="appointment_form" name="appointment_form" class="mt-30" method="post" action="" enctype="multipart/form-data">
            <div class="row">
              <div class="col-sm-12">
                <div class="form-group mb-10">
                  <input name="fac_name" class="form-control" type="text" required="" placeholder="Enter Name" aria-required="true">
                </div>
              </div>
              <div class="col-sm-12">
                <div class="form-group mb-10">
                  <input name="fac_email" class="form-control required email" type="email" placeholder="Enter Email" aria-required="true">
                </div>
              </div>
              <div class="col-sm-12">
                <div class="form-group mb-10">
                  <input name="fac_phone" class="form-control required" type="text" placeholder="Enter Phone" aria-required="true">
                </div>
              </div>
              <div class="col-sm-12">
                <div class="form-group mb-10">
                  <input name="fac_pass" class="form-control required " type="password" placeholder="Enter Password" aria-required="true">
                </div>
              </div>
              <div class="col-sm-12">
                <div class="form-group mb-10">
                  <input name="file1"  class="form-control required " type="file" placeholder="Upload Photo" aria-required="true">
                </div>
              </div>
            </div>
           
            <div class="form-group mb-0 mt-20">
              <input name="form_botcheck" class="form-control" type="hidden" value="">
              <input type="submit" class="btn btn-primary" value="Proceed">
            </div>
          </form>
          
        </div>
      </div>
    </div>
  </div>
</section>
</div>  

<?php

if($_POST)
{ 

  // $file=htmlspecialchars($_POST['fac_email']);
  extract($_POST);

 $tmp = $_FILES['file1']['tmp_name'];
 $name = $_FILES['file1']['name'];

 $folder = "faculty/uploads/fac_personal/";

 $merge = $folder.$name;

  move_uploaded_file($tmp,$merge);
 
//  $fac_name=htmlspecialchars($_POST['fac_name']);
//  $fac_email=htmlspecialchars($_POST['fac_email']);
//  $fac_phone=htmlspecialchars($_POST['fac_phone']);
//  $fac_pass=htmlspecialchars($_POST['fac_pass']);
 
  $checkname=preg_match("/^[a-zA-Z]{3,30}$/",$fac_name);
  $checkphone=preg_match("/^[0-9]{10,10}$/",$fac_phone);
  $checkemail=filter_var($fac_email,FILTER_VALIDATE_EMAIL);
  
  if($checkname && $checkphone)
  {
  
      $query=mysqli_query($con,"SELECT * FROM faculty_personal WHERE email='$fac_email'");

      if(mysqli_num_rows($query)==0)
      {
          mysqli_query($con,"INSERT INTO faculty_personal VALUES('','$fac_name','$fac_email','$fac_phone','$fac_pass','$merge');");
          
          $_SESSION['session']=$fac_email;
          header("location:register_fac2.php");
      }
      else{
        echo "Error.Already Registered! try again!!";
      }
 
  }
  else{
    echo "Invalid Credentials";
  }


}



?>














<?php

include "footer.php";

?>
