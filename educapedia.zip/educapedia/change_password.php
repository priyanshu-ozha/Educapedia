<?php
include "connection.php";
ob_start();
session_start();
$email = $_SESSION['mysession'];

if(!$email)
{
    header("location:login.php");
}

 include "header.php";
 include "connection.php";



?>



  
  <!-- Start main-content -->

    
      
    <!-- Section: Student Details -->
    
                
               
              <!-- Portfolio Gallery Grid -->
            

              <div class="gallery-isotope grid-4 gutter-small clearfix" data-lightbox="gallery">
        
              </div>
              <!-- End Portfolio Gallery Grid -->

             

              <div class="row">
                <?php
                    $query = mysqli_query($con,"select * from students where email='$email'");
                    while($k = mysqli_fetch_array($query))
                    {
                        $name = $k['name'];
                        $mobile = $k['mobile'];
                        $email = $k['email'];
                        $country = $k['country'];

                    }
                ?>
                
               <div class="col-md-12 mb-30">
                    <strong>Change Password</strong> 
                    <div class="col-md-3">
                        <br> <br>
                            <img src="images/faculty-icon-7.jpg" style="width:200px" alt="">
                    </div>

                    <div class="col-md-9">
                      <?php
                            $otp = rand(1000,9999);
                            mysqli_query($con,"INSERT INTO otp VALUES('','$email','$otp')");
                            // send email 
                            mail($email, "abc@gmail.com", "New OTP",$otp);

                        ?>
                        <form action="" method="post">
                            Enter OTP Received on your Email :
                            <input type="text" name="o1" value="<?php echo $otp; ?>">
                            <input type="submit" name="submit" value="Proceed">
                        </form>
                        <?php
                        if(isset($_POST['submit']))
                        {
                            extract($_POST);

                            $q2 = mysqli_query($con,"SELECT * from otp where email='$email' and otp='$o1'");

                            if(mysqli_num_rows($q2)==0)
                            {
                                echo "Invalid OTP. Try again!";
                            }
                            else
                            {
                                mysqli_query($con,"DELETE from otp where email='$email'");
                                ?>
                                <form action="" method="post">
                                    New Password :
                                    <input type="text" name="password" class="form-control">
                                    <br>
                                    <input type="submit" value="Change" name="change">
                                </form>
                                <?php
                            }
                        }
                        
                        if(isset($_POST['change']))
                        {
                            extract($_POST);

                            mysqli_query($con, "UPDATE students set password='$password' where email='$email'");

                            header("location:dashboard.php");
                        }
?>
                
               </div>
             </div>
             
            
            
            </div>
            <div class="col-sx-12 col-sm-4 col-md-4 sidebar pull-left">
              
              <h4 class="line-bottom">Dashboard | <b><?php echo $email; ?></b></h3></h4>
              <div class="volunteer-address">
                <ul>
                  <li>
                    <div class="bg-light media border-bottom-theme-colored-2px p-15 mb-20">
                      <div class="media-left">
                        <i class="fa fa-book text-theme-colored font-24 mt-5"></i>
                      </div>
                      <div class="media-body">
                       <a href="my-courses.php">My Courses</a>
                      
                      </div>
                    </div>

                    <div class="bg-light media border-bottom-theme-colored-2px p-15 mb-20">
                      <div class="media-left">
                        <i class="fa fa-user text-theme-colored font-24 mt-5"></i>
                      </div>
                      <div class="media-body">
                       
                       <a href="#">Edit Profile</a>
                      </div>
                    </div>

                    <div class="bg-light media border-bottom-theme-colored-2px p-15 mb-20">
                      <div class="media-left">
                        <i class="fa fa-sign-out font-24 mt-5"></i>
                      </div>
                      <div class="media-body">
                       
                       <a href="logout.php">Signout</a>
                      </div>
                    </div>
                  </li>
                </ul>
              </div>
          </div>
        </div>
      </div>
    </section>

  </div>
  <!-- end main-content -->

  
  
  <!-- Footer -->
 






<?php
include "footer.php";

?>