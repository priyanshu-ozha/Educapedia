<?php


 include "header.php";
 include "connection.php";
 if(!$email){
   header("location:login.php");
 }
 $p=mysqli_query($con,"SELECT * FROM students");
 while($z=mysqli_fetch_array($p)){
   $name=$z['name'];
   $mobile=$z['mobile'];
   $country=$z['country'];
 }



?>

   <!-- Start main-content -->
 <div class="main-content">

 

<section float="left">
  <div class="container">
    <div class="row">
      <div class="col-md-6 col-md-push-3">
        <div class="border-1px p-25">

          <form id="appointment_form" name="appointment_form" class="mt-30" method="post" action="" enctype="multipart/form-data">
            <div class="row">
              <div class="col-sm-12">
                <div class="form-group mb-10">
                  <input name="myname" class="form-control required " type="text" aria-required="true" value=" <?php echo $name; ?>">
                </div>
              </div>
              <div class="col-sm-12">
                <div class="form-group mb-10">
                  <input name="mymobile" class="form-control required " type="text" aria-required="true" value=" <?php echo $mobile; ?>">
                </div>
              </div>
              <div class="col-sm-12">
                <div class="form-group mb-10">
                  <input name="mycountry" class="form-control required " type="text" aria-required="true" value=" <?php echo $country; ?>">
                </div>
              </div>
              <div class="col-sm-12">
                <div class="form-group mb-10">
                  <input name="file1"  class="form-control required " type="file" placeholder="Upload Photo" aria-required="true">
                </div>
             
             
              
              
            </div>
           
            <div class="form-group mb-0 mt-20">
              <input name="form_botcheck" class="form-control" type="hidden" value="">
              <input type="submit" class="btn btn-primary" value="Login">
            </div>
          </form>
          
        </div>
      </div>
    </div>
  </div>
</section>
</div>  
<?php

if($_POST){
  extract($_POST);
  $tmp = $_FILES['file1']['tmp_name'];
  $name = $_FILES['file1']['name'];
 
  $folder = "faculty/uploads/stu/";
 
  $merge = $folder.$name;
 
   move_uploaded_file($tmp,$merge);
  
  mysqli_query($con, " UPDATE students
      SET name = '$myname',
      mobile = '$mymobile',
      country= '$mycountry',
      photo='$merge' where email='$email'");
  
 
  
  echo "<script>alert('Profile Updated Successfully!!');</script>";
  echo "<script>window.location.href='dashboard.php';</script>";
}


?>





<?php
include "footer.php";

?>