<?php
$con = mysqli_connect("localhost","root","","edu");
?>