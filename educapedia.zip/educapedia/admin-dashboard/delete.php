<?php

$id=$_GET['id'];
$type=$_GET['type'];
$conn=mysqli_connect("localhost","root","","edu");
if($type=='category')
{

mysqli_query($conn,"DELETE FROM categories WHERE id='$id'");
header("location:categorylist.php");
}
else if($type=='course')
{
  
    mysqli_query($conn,"DELETE FROM courses WHERE id='$id'");
    header("location:courselist.php");
}
?>